#ifndef SLIDER_H_
#define SLIDER_H_


void SLIDER_init();
void SLIDER_poll();

#endif
#include <stdio.h>

#ifndef SERVO_H_
#define SERVO_H_

void SERVO_init();
void SERVO_set(uint16_t posision);
void SERVO_test();


#endif /* SERVO_H_ */
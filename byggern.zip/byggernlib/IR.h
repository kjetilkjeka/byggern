#ifndef IR_H_
#define IR_H_

#define IRINT_vect INT7_vect

void IR_init();
int IR_count(void);



#endif
#ifndef EXTMEM_H_
#define EXTMEM_H_

void EXTMEM_init(void);



#endif
#ifndef SOLENOID_H_
#define SOLENOID_H_

void SOLENOID_init();
void SOLENOID_fire();


#endif
#ifndef SRAM_H
#define SRAM_H

void SRAM_test(void);
void SRAM_test2(int place);
void SRAM_init(void);

#endif
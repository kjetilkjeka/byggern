#ifndef EXTMEM_H_
#define EXTMEM_H_

char ADC_read(int port);




#endif